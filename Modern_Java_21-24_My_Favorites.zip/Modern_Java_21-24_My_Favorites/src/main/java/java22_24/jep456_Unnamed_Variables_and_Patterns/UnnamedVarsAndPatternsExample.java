package java22_24.jep456_Unnamed_Variables_and_Patterns;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21/22" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23/24 by Michael Inden
 */
public class UnnamedVarsAndPatternsExample
{
	public static void main(final String[] args)
	{
		String userInput = "E605";
		try
		{
			processInput(Integer.parseInt(userInput));
		}
		catch (NumberFormatException _) // $\mbox{\bfseries UNNAMED VARIABLE}$
		{
			System.out.println("Expected number, but was: '" + userInput + "'");
		}

		enum Color { RED, GREEN, BLUE, BLACK, WHITE };
		record Point(int x, int y) { };
		record ColoredPoint(Point point, Color color) { };

		var cp = new ColoredPoint(new Point(1234, 567), Color.BLUE);

		if (cp instanceof ColoredPoint(Point(int x,
											 var _), // $\mbox{\bfseries UNNAMED PATTERN VARIABLE}$
									   _)) // $\mbox{\bfseries UNNAMED PATTERN}$
		{
			System.out.println("x: " + x);
		}
	}

	private static void processInput(int i)
	{
		System.out.println("Input " + i);
	}
}
