package work.solutions.exercise1_Statements_Before_Super;

import java.awt.*;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class RectangleV2 extends ColoredShape {
    private final int width;
    private final int height;

    public RectangleV2(Color color, int x, int y, int width, int height) {
        if (width < 1 || height < 1)
            throw new IllegalArgumentException("width and height must be positive");

        super(color, x, y);
        this.width = width;
        this.height = height;
    }
}